#!/usr/bin/python
#Author=LPP
from lpp import *
RAW = blast_parse( open(sys.argv[1],'rU'), open(sys.argv[2],'w')  )
RAW.parse()