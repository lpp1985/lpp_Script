#!/usr/bin/Rscript
# functions
source("http://www.bioconductor.org/biocLite.R")
biocLite("DESeq")
